#!/usr/bin/env python
# coding=utf-8
  ############################
 #   Author tr0uble_mAker   #
###########################

from inc import console

def main():

    console.pocbomber_console()

if __name__ == '__main__':
    main()



